// Package checkers provides functions and structures to verify common types and aggregate
// errors.
package checkers
