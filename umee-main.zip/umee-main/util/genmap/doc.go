// Package genmap provides generic functions for manipulating maps.
package genmap
