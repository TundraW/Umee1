package tests

// file to import test / tools dependencies and let the go package manager to manage them.

import (
	_ "github.com/golang/mock/gomock"
)
