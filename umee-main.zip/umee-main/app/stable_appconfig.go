//go:build !experimental
// +build !experimental

package app

// Experimental is a flag which determines experimental features.
// It's set via build flag.
const Experimental = false
