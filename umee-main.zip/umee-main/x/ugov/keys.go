package ugov

const (
	// ModuleName defines the module name
	ModuleName = "ugov"

	// StoreKey defines the primary module store key
	StoreKey = ModuleName
)
