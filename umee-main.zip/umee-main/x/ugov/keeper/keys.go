package keeper

// store key prefixes
var (
	keyMinGasPrice = []byte{0x01}
)
