// Package fixtures provides test data for tests
package fixtures
