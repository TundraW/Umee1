package types

const FlagEnableLiquidatorQuery = "enable-liquidator-query"
