package types

const SecondsPerYear = 31536000
