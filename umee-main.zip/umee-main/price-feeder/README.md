# Oracle Price Feeder

After Umee Version v4.2.x, the Umee `price-feeder` built in the Umee project is now deprecated. The recommended `price-feeder` to run along the Umee node should be the [umee branch](https://github.com/ojo-network/price-feeder/tree/umee) of the Ojo Network's `price-feeder`.
