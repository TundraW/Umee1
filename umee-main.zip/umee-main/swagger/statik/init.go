package statik
